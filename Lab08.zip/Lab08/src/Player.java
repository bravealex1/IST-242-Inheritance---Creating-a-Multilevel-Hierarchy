/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author adamblady
 */
public abstract class Player extends Student{
    private int number;
    private String sports;
    private int gamesPlayed;

    public Player(int number, String sports, int gamesPlayed, String major, String academicYear, double GPA, String firstName, String lastName, String hometown, String state, Height height) {
        super(major, academicYear, GPA, firstName, lastName, hometown, state, height);
        this.number = number;
        this.sports = sports;
        this.gamesPlayed = gamesPlayed;
    }

    public Player() {
        super();
        this.number = 0;
        this.sports = "none";
        this.gamesPlayed = 0;
    }

    @Override
    public String toString() {
        return super.toString() + " Player{" + "number=" + number + ", sports=" + sports + ", gamesPlayed=" + gamesPlayed + '}' + "\n";
    }

    public abstract double getRatings();
    
    
    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getSports() {
        return sports;
    }

    public void setSports(String sports) {
        this.sports = sports;
    }

    public int getGamesPlayed() {
        return gamesPlayed;
    }

    public void setGamesPlayed(int gamesPlayed) {
        this.gamesPlayed = gamesPlayed;
    }
    
    
    
    
}
