/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author adamblady
 */
public class App {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SoccerPlayer sp0 = new SoccerPlayer();
        
        SoccerPlayer sp1 = new SoccerPlayer(5, 2, 7, "Soccer", 10, "Cyber", "Sr.", 3.5, "jillian", "Jennings", "Montclair", "NJ", new Height(5, 7));
        
        FootballPlayer fp0 = new FootballPlayer();
        
        FootballPlayer fp1 = new FootballPlayer(60, 30, 26, "Football", 10, "IST", "Jr.", 3.5, "KEATON", "Ellis", "State College", "PA", new Height(5, 11));
        
        
        
        System.out.println(sp0.toString());
        System.out.println(sp1.toString());
        System.out.println(fp0.toString());
        System.out.println(fp1.toString());

        
        
    }
    
}
