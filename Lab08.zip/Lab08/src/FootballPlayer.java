/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author adamblady
 */
public class FootballPlayer extends Player{
    private int yards;
    private int minutesPlayed;

    public FootballPlayer(int yards, int minutesPlayed, int number, String sports, int gamesPlayed, String major, String academicYear, double GPA, String firstName, String lastName, String hometown, String state, Height height) {
        super(number, sports, gamesPlayed, major, academicYear, GPA, firstName, lastName, hometown, state, height);
        this.yards = yards;
        this.minutesPlayed = minutesPlayed;
    }

    public FootballPlayer() {
        super();
        this.yards = 0;
        this.minutesPlayed = 0;
    }

    @Override
    public String toString() {
        return super.toString() + " FootballPlayer{" + "yards=" + yards + ", minutesPlayed=" + minutesPlayed + ", ratings=" + getRatings() + '}' + "\n" + "==============================================================";
    }
    
    @Override
    public double getRatings(){
        double ratings = (double) ((yards - minutesPlayed/10.0)) / getGamesPlayed();
        if(yards == 0 || getGamesPlayed() == 0){
            return 0;
        }
        return ratings;
    }

    public int getYards() {
        return yards;
    }

    public void setYards(int yards) {
        this.yards = yards;
    }

    public int getMinutesPlayed() {
        return minutesPlayed;
    }

    public void setMinutesPlayed(int minutesPlayed) {
        this.minutesPlayed = minutesPlayed;
    }
    
    
    
}
