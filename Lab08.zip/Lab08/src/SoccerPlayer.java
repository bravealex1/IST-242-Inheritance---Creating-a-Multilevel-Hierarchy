/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author adamblady
 */
public class SoccerPlayer extends Player{
    private int goals;
    private int yellowCards;

    public SoccerPlayer(int goals, int yellowCards, int number, String sports, int gamesPlayed, String major, String academicYear, double GPA, String firstName, String lastName, String hometown, String state, Height height) {
        super(number, sports, gamesPlayed, major, academicYear, GPA, firstName, lastName, hometown, state, height);
        this.goals = goals;
        this.yellowCards = yellowCards;
    }

    public SoccerPlayer() {
        super();
        this.goals = 0;
        this.yellowCards = 0;
    }

    @Override
    public String toString() {
        return super.toString() + " SoccerPlayer{" + "goals=" + goals + ", yellowCards=" + yellowCards + ", ratings=" + getRatings() + '}' + "\n" + "==============================================================";
    }
    
    
    @Override
    public double getRatings(){
        double ratings = (double) (goals - yellowCards)/getGamesPlayed();
        if(goals == 0 || getGamesPlayed() == 0){
            return 0;
        }
        return ratings;
    }
    

    public int getGoals() {
        return goals;
    }

    public void setGoals(int goals) {
        this.goals = goals;
    }

    public int getYellowCards() {
        return yellowCards;
    }

    public void setYellowCards(int yellowCards) {
        this.yellowCards = yellowCards;
    }  
    
    
}
