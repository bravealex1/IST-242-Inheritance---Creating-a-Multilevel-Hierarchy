/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author adamblady
 */
public class Person {
    private String firstName;
    private String lastName;
    private String hometown;
    private String state;
    private Height height;

    
    
    public Person(){
        this.firstName = "No";
        this.lastName = "Name";
        this.hometown = "N/A";
        this.state = "N/A";
        this.height = new Height();
        setLastName(lastName);
    }
    
    public Person(String firstName, String lastName, Height height){
        this.firstName = firstName;
        this.lastName = lastName;
        this.hometown = "N/A";
        this.state = "N/A";
        this.height = height;
        setLastName(lastName);
    }
    
    public Person(String firstName, String lastName, String hometown, String state, Height height){
        this.firstName = firstName;
        this.lastName = lastName;
        this.hometown = hometown;
        this.state = state;
        this.height = height;
        setLastName(lastName);
    }

    @Override
    public String toString() {
        return "Person{" + "firstName=" + getFirstName() + ", lastName=" + lastName + ", hometown=" + hometown + ", state=" + state + ", height=" + height + '}' + "\n";
    }
    
    
    

    
    
    public void initials(){
        System.out.println(firstName.substring(0,1) + "." + lastName.substring(0,1) + ".");
    }
    
    public void initials(int option){
        if(option == 1){
            System.out.println(firstName.substring(0,1) + "." + lastName + ".");
        }
        if(option == 2){
            System.out.println(firstName + "." + lastName.substring(0,1) + ".");
        }
    }

    public String getFirstName(){
        return firstName.substring(0,1).toUpperCase() + firstName.substring(1).toLowerCase();
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName.toUpperCase();
    }

    public String getHometown() {
        return hometown;
    }

    public void setHometown(String hometown) {
        this.hometown = hometown;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Height getHeight() {
        return height;
    }

    public void setHeight(Height height) {
        this.height = height;
    }
    
    
}
