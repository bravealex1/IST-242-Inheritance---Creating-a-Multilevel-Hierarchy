/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author adamblady
 */
public class Student extends Person{
    private String major;
    private String academicYear;
    private double GPA;

    public Student(String major, String academicYear, double GPA, String firstName, String lastName, String hometown, String state, Height height) {
        super(firstName, lastName, hometown, state, height);
        this.major = major;
        this.academicYear = academicYear;
        this.GPA = GPA;
    }

    public Student() {
        super();
        this.major = "IST";
        this.academicYear = "Sr.";
        this.GPA = 3.0;
    }

    @Override
    public String toString() {
        return super.toString() + " Student{" + "major=" + major + ", academicYear=" + academicYear + ", GPA=" + GPA + '}' + "\n";
    }
    
    

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getAcademicYear() {
        return academicYear;
    }

    public void setAcademicYear(String academicYear) {
        this.academicYear = academicYear;
    }

    public double getGPA() {
        return GPA;
    }

    public void setGPA(double GPA) {
        this.GPA = GPA;
    }
    
    
}
